package com.example.template;
import java.util.ArrayList;

public class Animal {
    protected Location location;
    private ArrayList<Location> possibleMoves = new ArrayList<>();
    protected String piececolor;
    protected int age;
    protected String gender;
    protected boolean isdead=false;

    public Animal(String gender,String piececolor,int row, int col){
        this.gender=gender;
        location=new Location(row,col);
        this.piececolor=piececolor;
        this.age=19;
        ageup();
    }
    public void findPossibleMoves(Tile[][] tiles){
        //within 1 square
        possibleMoves.clear();
        for (int i = Math.max(0, location.getRow() - 1); i <= Math.min(tiles.length - 1, location.getRow() + 1); i++) {
            for (int j = Math.max(0, location.getCol() - 1); j <= Math.min(tiles[i].length - 1, location.getCol() + 1); j++) {
                if (!tiles[i][j].getOccupied()) {
                    possibleMoves.add(new Location(i, j));
                }
            }
        }

    }
    public void ageup(){
        age+=1;
        if (age==20){
            int rnum=(int)(Math.random()*2);
            if (rnum==1){
                gender="male";
            }else if (rnum==0){
                gender="female";
            }
        }
        if (age>60){
            int rnum=(int)(Math.random()*100);
            rnum+=age-60;
            if (rnum>70){
                isdead=true;
            }

        }
    }


    public void moveRandom(Tile[][] tiles){
        findPossibleMoves(tiles);
        if (possibleMoves.size() == 0) return;
        int rnum = (int)(Math.random() * possibleMoves.size());
        location = possibleMoves.get(rnum);

        possibleMoves.clear();
    }
    public Location getlocation(){
        return location;
    }

    public int getage(){
        return age;
    }
    public String getgender(){
        return gender;
    }
    public String getpiececolor(){
        return piececolor;
    }
}
