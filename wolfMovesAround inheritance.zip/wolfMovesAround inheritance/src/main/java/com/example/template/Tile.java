package com.example.template;

public class Tile {
    final String[][] TERRAINCOLORS={{"d","-fx-background-color: #696969;"}};
    private String terraintype;

    private String tileColor;
    private boolean isOccupied;
    public Tile(boolean isOccupied,String terraintype) {
        this.isOccupied = isOccupied;
        this.terraintype=terraintype;
        this.tileColor = TERRAINCOLORS[0][1];
    }
    private String getterraitype(){
        return terraintype;
    }


    public void setPieceColor(String pieceColor) {
        this.tileColor = pieceColor;
    }

    public boolean getOccupied() {
        return isOccupied;
    }
    public String getterraincolor(){
        return tileColor;
    }
}
