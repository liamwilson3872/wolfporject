package com.example.template;

import java.util.ArrayList;

public class Wolf extends Animal {
    private Tile[][] tiles;
    public Wolf(String gender, String piececolor,int row,int col,Tile[][] tiles){
        super(gender,piececolor,row,col);
        this.tiles=tiles;
    }
    public void wolfmove(Tile[][] tiles){
        boolean wolfmove=false;
        if (wolfmove){
            //put specific wolf moving code here
        }else{
            super.moveRandom(tiles);
        }
    }





}
