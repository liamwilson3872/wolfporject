package com.example.template;

import java.util.ArrayList;

public class GamePlay {
    private Tile[][] tiles;
    private ArrayList<Animal> animals = new ArrayList<>();

    public GamePlay() {

    }

    public void createBoard(){


        final String[] MAZE = new String[] {
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "..............."
        };

        // Safety: ensure tiles is allocated correctly
        this.tiles = new Tile[15][15];

        for (int r = 0; r < 15; r++) {
            String row = MAZE[r];
            for (int c = 0; c < 15; c++) {
                char ch = row.charAt(c);
                switch (ch) {
                    default:
                        tiles[r][c] = new Tile( false, "d");
                        break;
                }
            }
        }

    }

    public Tile[][] getTiles() {
        return tiles;
    }
    public void changeTileColor(int row, int col,String pieceColor){
        tiles[row][col].setPieceColor(pieceColor);
    }
    public ArrayList<Animal> getanimals(){
        return animals;
    }
    public void addanimal(String animal){
        if (animal.equals("wolf")){
            animals.add(new Wolf("female","-fx-background-color: white;",5,5,tiles));

        }
    }
    public void moveanimals(){
        for (int i=0;i<animals.size();i++){
            Animal animal=animals.get(i);
            if (animal instanceof Wolf){
                ((Wolf) animal).wolfmove(tiles);
            }
        }
    }


}
