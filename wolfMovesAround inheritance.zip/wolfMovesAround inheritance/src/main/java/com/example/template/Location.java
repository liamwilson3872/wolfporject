package com.example.template;

public class Location {
    private int row;
    private int col;
    public Location(int r, int c){
        this.row = r;
        this.col = c;
    }

    public int getCol() {
        return col;
    }

    public int getRow() {
        return row;
    }
}
