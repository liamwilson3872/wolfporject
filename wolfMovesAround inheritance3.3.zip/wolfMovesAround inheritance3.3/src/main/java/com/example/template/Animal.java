package com.example.template;
import java.util.ArrayList;

public class Animal {
    protected Location location;
    private ArrayList<Location> possibleMoves = new ArrayList<>();
    protected String piececolor;
    protected int age;
    protected String gender;
    protected boolean isdead=false;
    private String id;
    protected long timeuntilmove;
    protected long timeelapsed;

    public Animal(String gender,String piececolor,int row, int col,long timeuntilmove){
        this.gender=gender;
        location=new Location(row,col);
        this.piececolor=piececolor;
        this.age=19;
        ageup();
        this.gender=gender;
        this.timeuntilmove=timeuntilmove;
    }
    public void findPossibleMoves(Tile[][] tiles){
        //within 1 square
        possibleMoves.clear();
        for (int i = Math.max(0, location.getRow() - 1); i <= Math.min(tiles.length - 1, location.getRow() + 1); i++) {
            for (int j = Math.max(0, location.getCol() - 1); j <= Math.min(tiles[i].length - 1, location.getCol() + 1); j++) {
                if (!tiles[i][j].getOccupied()) {
                    possibleMoves.add(new Location(i, j));
                }
            }
        }

    }
    public long getTimeelapsed(){
        return timeelapsed;
    }
    public long getTimeuntilmove(){
        return timeuntilmove;
    }
    public void ageup(){

    }
    public Boolean getisdead(){
        return isdead;
    }
    public void setid(){
        id=age+gender;
    }

    public String getid(){
        return id;
    }

    public void moveRandom(Tile[][] tiles){

        findPossibleMoves(tiles);
        if (possibleMoves.size() == 0) return;
        int rnum = (int)(Math.random() * possibleMoves.size());
        location = possibleMoves.get(rnum);

        possibleMoves.clear();
    }
    public Location getlocation(){
        return location;
    }

    public int getage(){
        return age;
    }
    public String getgender(){
        return gender;
    }
    public String getpiececolor(){
        return piececolor;
    }
    public ArrayList<Animal> breed(ArrayList<Animal> animals){
      for (int i=0;i<animals.size();i++){
          if (animals.get(i)==this){
              Animal animal1=this;
              Animal animal2=isthereananimalontop(animals,animal1);
              if ()//checks if diffrent genders
          }
      }

    }
    public Animal isthereananimalontop(ArrayList<Animal> animals,Animal animal){
            for (int j=0;j<animals.size();j++) {
                if (animal.getlocation().getRow() == animals.get(j).getlocation().getRow() && animal.getlocation().getCol() == animals.get(j).getlocation().getCol()) {
                    System.out.println("on top");
                    return animals.get(j);

                }

            }

        return null;
    }
}
