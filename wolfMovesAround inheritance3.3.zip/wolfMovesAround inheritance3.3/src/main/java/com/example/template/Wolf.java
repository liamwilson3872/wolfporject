package com.example.template;

import java.util.ArrayList;

public class Wolf extends Animal {
    private Tile[][] tiles;
    public Wolf(String gender, String piececolor,int row,int col,Tile[][] tiles, long timeuntilmove){
        super(gender,piececolor,row,col,timeuntilmove);
        this.tiles=tiles;
    }
    public void wolfmove(Tile[][] tiles){
        boolean wolfmove=false;
        age+=1;
        if (age==20){
            int rnum=(int)(Math.random()*2);
            if (rnum==1){
                gender="M";
            }else if (rnum==0){
                gender="F";
            }
        }
        if (age>60){
            int rnum=(int)(Math.random()*100);
            rnum+=age-70;
            if (rnum>60){
                isdead=true;
            }

        }
        if (wolfmove){
            //put specific wolf moving code here
        }else{
            super.moveRandom(tiles);
        }
    }





}
