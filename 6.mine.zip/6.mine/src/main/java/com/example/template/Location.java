package com.example.template;

public class Location {
    private int row;
    private int col;
    public Location(int row, int col) {
        this.row = row;
        this.col = col;
    }
    public int getRow() {
        return row;
    }
    public int getCol() {
        return col;
    }
    public boolean comparecords(int x1,int y1){
        if ((x1==row)&&(y1==col)){
            return true;
        }else{
            return false;
        }
    }
}
