package com.example.template;

import java.util.ArrayList;

public class GamePlay {
    private Tile[][] tiles;
    private ArrayList<Animal> animals = new ArrayList<>();
    public GamePlay() {

    }

    public void createBoard(){
        final String[] MAZE = new String[] {
                "...............",
                "wwww...........",
                "wwww...........",
                "...............",
                ".........ffffff",
                "............fff",
                "....wwww....fff",
                "....wwww.......",
                "...............",
                "...............",
                "....ggggggg....",
                "....ggggggg....",
                "....ggggggg....",
                "...............",
                "..............."
        };

        // Safety: ensure tiles is allocated correctly
        this.tiles = new Tile[15][15];

        for (int r = 0; r < 15; r++) {
            String row = MAZE[r];
            for (int c = 0; c < 15; c++) {
                char ch = row.charAt(c);
                switch (ch) {
                    case 'w':
                        tiles[r][c] = new Tile( false, "w");//water
                        break;
                    case 'f':
                        tiles[r][c] = new Tile( false, "f");//forest
                        break;
                    case 'g':
                        tiles[r][c] = new Tile(false, "g");//grass
                        break;
                    case '.':
                    default:
                        tiles[r][c] = new Tile( false, "d");//dirt
                        break;
                }
            }
        }

    }

    public Tile[][] getTiles() {
        return tiles;
    }

    public void addAnimal(String animal) {
        if(animal.equals("Wolf")){
            int randomGender = (int) (Math.random() * 2);
            ArrayList<String> terrainitcanmoveon=new ArrayList<>();
            terrainitcanmoveon.add("f");
            terrainitcanmoveon.add("g");
            terrainitcanmoveon.add("d");

            if(randomGender == 0){

                animals.add(new Wolf("Female", "-fx-background-color: #FFCCCB ;", 5, 5,1000000000,terrainitcanmoveon));
            }else {
                animals.add(new Wolf("Male", "-fx-background-color: #FFCCCB ;", 5, 5,1000000000,terrainitcanmoveon));
            }
        }
        if(animal.equals("Sheep")){
            int randomGender = (int) (Math.random() * 2);

            ArrayList<String> terrainitcanmoveon=new ArrayList<>();
            terrainitcanmoveon.add("f");
            terrainitcanmoveon.add("g");
            terrainitcanmoveon.add("d");
            if(randomGender == 0){
                animals.add(new Sheep("Female", "-fx-background-color: white ;", 5, 5,1000000000,terrainitcanmoveon));
            }else {
                animals.add(new Sheep("Male", "-fx-background-color: white ;", 5, 5,1000000000,terrainitcanmoveon));
            }
        }

    }
    public void movePiece(){
        long currentTime = System.nanoTime();
        for (int i = 0; i < animals.size(); i++) {
            Animal animal = animals.get(i);

            if (currentTime - animal.getTimeElapsed() >= animal.getTimeUntilMove()) {
                boolean isthereprey=false;
                if (animal instanceof Wolf) {
                    for (int j=0;j<animals.size();j++){
                        if (animals.get(j) instanceof Sheep){
                            isthereprey=true;
                        }
                    }
                    if (isthereprey) {
                        ((Wolf) animal).wolfmove(tiles, animals);
                        animal.setTimeElapsed();
                        for (int manning=0;manning<animals.size();manning++){
                            if ((compare2animalslocation(animal,animals.get(manning)))&&animals.get(manning) instanceof Sheep){
                                animals.remove(manning);
                                animals.get(i).eat(100);
                            }
                        }

                    }else{
                        animal.move(tiles);
                        animal.setLastMoveTime(currentTime);
                    }
                }
            }


        }
    }
    public void starvation(){
        for (int i=0;i<animals.size();i++){
            if (animals.get(i).gethunger()<1){
                animals.remove(i);
                System.out.println("an animal has starved");
            }
        }
    }

    public ArrayList<Animal> getAnimals() {
        return animals;
    }
    public boolean compare2animalslocation(Animal animal1,Animal animal2){
        if (animal1.getLocation().comparecords(animal2.getLocation().getRow(),animal2.getLocation().getCol())){
            return true;
        }else{
            return false;
        }
    }
}
