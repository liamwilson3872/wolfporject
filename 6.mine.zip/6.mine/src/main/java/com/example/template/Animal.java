package com.example.template;

import java.util.ArrayList;

public class Animal {
    protected String gender;
    protected String pieceColor;
    protected Location location;
    private ArrayList<Location> possibleMoves = new ArrayList<>();
    protected String abbreviation;
    protected long timeUntilMove;
    protected long timeElapsed;
    protected int hunger;
    protected ArrayList<String> wherecanitmove=new ArrayList<>();
    public Animal(String gender,String pieceColor,int row,int col,long timeUntilMove,ArrayList<String> canmove) {
        this.gender = gender;
        this.pieceColor = pieceColor;
        location = new Location(row,col);
        abbreviation = "W";
        this.timeUntilMove = timeUntilMove;
        timeElapsed = System.nanoTime();
        wherecanitmove=canmove;
        hunger=100;
        
    }

    public void setTimeElapsed() {
        timeElapsed = System.nanoTime();
    }

    public long getTimeUntilMove() {
        return timeUntilMove;
    }
    public long getTimeElapsed() {
        return timeElapsed;
    }
    public void setLastMoveTime(long timeElapsed) {
        this.timeElapsed = timeElapsed;
    }

    public Location getLocation() {
        return location;
    }

    public String getAbbreviation() {
        System.out.println(abbreviation);
        return abbreviation;
    }

    public String getGender() {
        return gender;  
    }

    public String getPieceColor() {
        return pieceColor;
    }
    
    public void move(Tile[][] tiles){
        findPossibleMoves(tiles);
        int moveLocation = (int) (Math.random() * possibleMoves.size());

        location = possibleMoves.get(moveLocation);

    }
    public void usefood(int amount){
        hunger-=amount;
    }
    public void eat(int amount){
        hunger+=amount;
    }
    public int gethunger(){
        return hunger;
    }
    public void findPossibleMoves(Tile[][] tiles){
        possibleMoves.clear();
        int currentRow = location.getRow();
        int currentCol = location.getCol();
        for (int i = Math.max(0, currentRow - 1); i <= Math.min(tiles.length - 1, currentRow + 1); i++) {
            for (int j = Math.max(0, currentCol - 1); j <= Math.min(tiles[i].length - 1, currentCol + 1); j++) {
                if (!tiles[i][j].getOccupied()) {
                    for (int paytonmanning=0;paytonmanning<wherecanitmove.size();paytonmanning++) {
                        if (tiles[i][j].getTerrainType().equals(wherecanitmove.get(paytonmanning))) {
                            possibleMoves.add(new Location(i, j));
                        }
                    }
                }
            }
        }
//        System.out.println(possibleMoves.size());
    }   
}
