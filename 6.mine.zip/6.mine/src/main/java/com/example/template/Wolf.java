package com.example.template;

import java.util.ArrayList;

public class Wolf extends Animal{
    private ArrayList<Sheep> sheeps=new ArrayList<>();
    private Sheep bestsheep;
    public Wolf(String gender, String pieceColor, int row, int col, long timeUntilMove, ArrayList<String> possible) {
        super(gender,pieceColor,row,col,timeUntilMove,possible);
    }
    public void wolfmove(Tile[][] tiles,ArrayList<Animal> animals){
//        boolean wolfMove = false;
//
//        if(wolfMove){
//            System.out.println("code wolf move");
//        }else{
//            super.move(tiles);
//        }
        wolfhuntprey(tiles,animals);


    }
    public void wolfhuntprey(Tile[][] tiles,ArrayList<Animal> animals){
        findanimal("Sheep",tiles,animals);
        bestsheep=findbestprey();
        int wolfrow = location.getRow();
        int wolfcol = location.getCol();
        int sheeprow = bestsheep.getLocation().getRow();
        int sheepcol = bestsheep.getLocation().getCol();
        int bestdistance = Integer.MAX_VALUE;
        int bestrow = wolfrow;
        int bestcol = wolfcol;
        for (int i = -1; i <= 1; i++){
            for (int j = -1; j <= 1; j++){
                int newrow = wolfrow + i;
                int newcol = wolfcol + j;
                if (!(i==0 && j==0) && (Math.abs(i)+Math.abs(j)==1) && (newrow>= 0&&newrow<tiles.length) && (newcol>= 0&& newcol<tiles[0].length)){
                    int distance = Math.abs(newrow-sheeprow)+Math.abs(newcol-sheepcol);
                    if (distance<bestdistance){
                        bestdistance = distance;
                        bestrow = newrow;
                        bestcol = newcol;
                    }
                }
            }
        }
        location = new Location(bestrow, bestcol);
        super.usefood(4);

    }


    public Sheep findbestprey(){
        int bestdistance=Integer.MAX_VALUE;
        Sheep closestprey =null;
        for (int i=0;i<sheeps.size();i++){
            Sheep currentsheep=sheeps.get(i);
            int distance=Math.abs(currentsheep.getLocation().getRow()-location.getRow())+Math.abs(currentsheep.getLocation().getCol()-location.getCol());
            if (distance<bestdistance){
                bestdistance=distance;
                closestprey =currentsheep;
            }
        }
        return closestprey;
    }
    public Sheep getbestprey(){
        return bestsheep;
    }

    public void findanimal(String animaltofind,Tile[][] tiles,ArrayList<Animal> animals){
        sheeps.clear();;
        for(int i=0;i<animals.size();i++){
            Animal animal=animals.get(i);
            if (animal instanceof Sheep){
                sheeps.add((Sheep)animal);
            }
        }

    }

}
