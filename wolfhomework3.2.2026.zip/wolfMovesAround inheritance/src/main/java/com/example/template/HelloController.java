package com.example.template;

import javafx.animation.AnimationTimer;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

public class HelloController {

    public Button btnClick;
    public Label lblDisplay;
    public TextField txtInput;
    public GridPane gpane;
    public AnchorPane anchor;
    private Button[][] btn;
    private GamePlay gamePlay = new GamePlay();
    private long timeElapsed;

    public void initialize(){
        anchor.setStyle("-fx-background-color: Black");
        gpane.setStyle("-fx-background-color: Blue");
    }

    public void handleClick(ActionEvent actionEvent) {
        int x = 15;//(int)(Math.random()*20);
        int y = 15;//(int)(Math.random()*20);
        btn = new Button[x][y];

        gpane.getChildren().clear();
        gpane.setGridLinesVisible(true);
        gpane.setStyle("-fx-background-color: #d3d3d3; -fx-border-color: #696969; -fx-border-width: 3px;");
        for (int i = 0; i < btn.length; i++) {
            for (int j = 0; j < btn[0].length; j++) {

                btn[i][j] = new Button();
                btn[i][j].setPrefSize(40,40);
                gpane.add(btn[i][j], j, i);
            }
        }

        // same structure, now for MouseEvent
        EventHandler<MouseEvent> z = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                System.out.println(event.getSource());
//                gpane.setGridLinesVisible(true);
                Button clicked = (Button) event.getSource();
                int row = GridPane.getRowIndex(clicked);
                int col = GridPane.getColumnIndex(clicked);
//                System.out.println("(" + row + "," + col + ")");

                if (event.getButton() == MouseButton.PRIMARY) {
//                    System.out.println("LEFT click");
//
//                    if (row == 0 || row == btn.length - 1 || col == 0 || col == btn[0].length - 1) {
//                        System.out.println("On the border");
//                    }else{
//                        System.out.println("on the inside");
//                    }

//                    gamePlay.changeTileColor(row,col,"-fx-background-color: #0000ff;");
                } else if (event.getButton() == MouseButton.SECONDARY) {
//                    System.out.println("RIGHT click");

                }

//                btn[row][col].setText("clicked");
                updateScreen();
            }
        };

        for (int i = 0; i < btn.length; i++) {
            for (int j = 0; j < btn[0].length; j++) {
                btn[i][j].setOnMouseClicked(z);   // same pattern as your setOnAction
            }
        }
        //resets the gridlines
        gpane.setGridLinesVisible(false);
        gpane.setGridLinesVisible(true);
        gridSetup();
        updateScreen();
        handleStartAnimation();
    }



    public void updateScreen(){
        //change a lot
        Tile[][] board = gamePlay.getTiles();

        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                btn[i][j].setStyle(board[i][j].getterraincolor());
            }

        }
        for (int i=0;i<gamePlay.getanimals().size();i++){
            btn[gamePlay.getanimals().get(i).getlocation().getRow()][gamePlay.getanimals().get(i).getlocation().getCol()].setStyle(gamePlay.getanimals().get(i).getpiececolor());
        }
    }
    public void gridSetup(){
        gamePlay.createBoard();

    }

    public void handleMove(ActionEvent actionEvent) {

        updateScreen();

    }
    private int delay=0;
    public void handleStartAnimation() {
        new AnimationTimer(){

            @Override
            public void handle(long now) {
                        //if you want a longer long variable use an l at the end of the number
                delay+=1;
                if (delay>5){
                    gamePlay.moveanimals();

                    delay=0;
                }else{

                }





                updateScreen();
            }

        }.start();
    }

    public void handleAddWolf(ActionEvent actionEvent) {
        gamePlay.addanimal("wolf");

    }
}