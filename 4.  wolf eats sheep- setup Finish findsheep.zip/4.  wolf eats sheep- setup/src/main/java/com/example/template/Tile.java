package com.example.template;

public class Tile {
    
    final String[][] TERRAIN_COLORS = {

            {"d", "-fx-background-color: #B1A688;"}
    };

    private String terrainType;
    private boolean isOccupied;
    private String tileColor;
    public Tile(boolean isOccupied,String terrainType) {
        this.isOccupied = isOccupied;
        this.terrainType = terrainType;
        for (int i = 0; i < TERRAIN_COLORS.length; i++) {
            if (terrainType.equals(TERRAIN_COLORS[i][0])) {
                tileColor = TERRAIN_COLORS[i][1];
                break;
            }
        }
        
    }
    public String getTerrainColor() {
        return tileColor;
    }
    public void setPieceColor(String terrainType) {
        this.terrainType = terrainType;
    }

    public boolean getOccupied() {
        return isOccupied;
    }
    public String getTerrainType() {
        return terrainType;
    }


}
