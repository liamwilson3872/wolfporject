package com.example.template;

import java.util.ArrayList;

public class Wolf extends Animal{
    private ArrayList<Sheep> sheep=new ArrayList<>();
    public Wolf(String gender,String pieceColor,int row,int col,long timeUntilMove,String abbreviation) {
        super(gender,pieceColor,row,col,timeUntilMove,abbreviation);
    }
    public void move(Tile[][] tiles, ArrayList<Animal> animals){
        boolean wolfMove = false;

        if(wolfMove){
            Location oldloco=location;
            location=new Location(oldloco.getRow()+1,oldloco.getCol()+1);


        }else{
            super.move(tiles,animals);
        }


    }
    public void findanimal(String animaltofind,Tile[][] tiles){

    }


}
