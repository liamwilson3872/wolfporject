package com.example.template;

import java.util.ArrayList;

public class Sheep extends Animal{

    public Sheep(String gender,String pieceColor,int row,int col,long timeUntilMove,String abbreviation) {
        super(gender,pieceColor,row,col,timeUntilMove,abbreviation);
    }
    public void move(Tile[][] tiles,ArrayList<Animal> animals){
        boolean sheepmove = false;

        if(sheepmove){

        }else{
            super.move(tiles,animals);
        }


    }

}
