package com.example.template;

import java.util.ArrayList;

public class GamePlay {
    private Tile[][] tiles;
    private ArrayList<Animal> animals = new ArrayList<>();
    public GamePlay() {

    }

    public void createBoard(){
        final String[] MAZE = new String[] {
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "...............",
                "..............."
        };

        // Safety: ensure tiles is allocated correctly
        this.tiles = new Tile[15][15];

        for (int r = 0; r < 15; r++) {
            String row = MAZE[r];
            for (int c = 0; c < 15; c++) {
                char ch = row.charAt(c);
                switch (ch) {

                    case '.':
                    default:
                        tiles[r][c] = new Tile( false, "d");
                        break;
                }
            }
        }

    }

    public Tile[][] getTiles() {
        return tiles;
    }

    public void addAnimal(String animal) {
        if(animal.equals("Wolf")){
            int randomGender = (int) (Math.random() * 2);
            if(randomGender == 0){
                animals.add(new Wolf("Female", "-fx-background-color: #FFCCCB ;", 5, 5,1000000000,"WF"));
            }else {
                animals.add(new Wolf("Male", "-fx-background-color: #FFCCCB ;", 5, 5,1000000000,"WM"));
            }
        }
        if(animal.equals("Sheep")){
            int randomGender = (int) (Math.random() * 2);
            if(randomGender == 0){
                animals.add(new Sheep("Female", "-fx-background-color: white ;", 5, 5,1000000000,"SF"));
            }else {
                animals.add(new Sheep("Male", "-fx-background-color: white ;", 5, 5,1000000000,"SM"));
            }
        }

    }
    public void movePiece(){
        long currentTime = System.nanoTime();
        for (int i = 0; i < animals.size(); i++) {
            Animal animal = animals.get(i);

            if (currentTime - animal.getTimeElapsed() >= animal.getTimeUntilMove()) {
//                if (animal instanceof Wolf) {
//                    ((Wolf) animal).wolfMove(tiles);
//                    animal.setTimeElapsed();
//                }
                animal.move(tiles,animals);
                animal.setLastMoveTime(currentTime);
            }


        }
    }

    public ArrayList<Animal> getAnimals() {
        return animals;
    }
}
