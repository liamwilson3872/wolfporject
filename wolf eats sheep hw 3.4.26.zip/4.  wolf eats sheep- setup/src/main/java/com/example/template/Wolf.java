package com.example.template;

import java.util.ArrayList;

public class Wolf extends Animal{
    private ArrayList<Sheep> sheeps=new ArrayList<>();
    private Sheep bestsheep;

    public Wolf(String gender,String pieceColor,int row,int col,long timeUntilMove,String abbreviation) {
        super(gender,pieceColor,row,col,timeUntilMove,abbreviation);
    }
    public void move(Tile[][] tiles, ArrayList<Animal> animals){
        boolean wolfMove = false;

        if(wolfMove){
            wolfhuntprey(findbestprey(),tiles);


        }else{
            super.move(tiles,animals);
        }


    }

    public void wolfhuntprey(Sheep prey, Tile[][] tiles){
        int wolfrow = location.getRow();
        int wolfcol = location.getCol();
        int sheeprow = prey.getLocation().getRow();
        int sheepcol = prey.getLocation().getCol();
        int bestdistance = Integer.MAX_VALUE;
        int bestrow = wolfrow;
        int bestcol = wolfcol;
        for (int i = -1; i <= 1; i++){
            for (int j = -1; j <= 1; j++){
                int newRow = wolfrow + i;
                int newCol = wolfcol + j;
                if (!(i == 0 && j == 0) && (Math.abs(i) + Math.abs(j) == 1) && (newRow >= 0 && newRow < tiles.length) && (newCol >= 0 && newCol < tiles[0].length)){
                    int distance = Math.abs(newRow - sheeprow) + Math.abs(newCol - sheepcol);
                    if (distance < bestdistance){
                        bestdistance = distance;
                        bestrow = newRow;
                        bestcol = newCol;
                    }
                }
            }
        }
        location = new Location(bestrow, bestcol);
    }
    

    public Sheep findbestprey(){
        int bestdistance=Integer.MAX_VALUE;
        Sheep closestprey =null;
        for (int i=0;i<sheeps.size();i++){
            Sheep currentsheep=sheeps.get(i);
            int distance=Math.abs(currentsheep.getLocation().getRow()-location.getRow())+Math.abs(currentsheep.getLocation().getCol()-location.getCol());
            if (distance<bestdistance){
                bestdistance=distance;
                closestprey =currentsheep;
            }
        }
        return closestprey;
    }

    public void findanimal(String animaltofind,Tile[][] tiles,ArrayList<Animal> animals){
        sheeps.clear();;
        for(int i=0;i<animals.size();i++){
            Animal animal=animals.get(i);
            if (animal instanceof Sheep){
                sheeps.add((Sheep)animal);
            }
        }

    }


}
